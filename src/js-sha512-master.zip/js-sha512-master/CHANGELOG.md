# v0.1.1 / 2014-07-27

Fixed accents bug

# v0.1.0 / 2014-01-05

Initial release
